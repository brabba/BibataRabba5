/*/*
 * *My name is Bibata Rabba and this is my own work.
 * *
 **/

import java.util.*;//

public class PlayerManager {//begin PlayerManager class

	final private static ArrayList<NFLPlayer> LIST_OF_PLAYERS = new ArrayList<>();//NFL Player Manager Class has an ArrayList that holds NFL Players

	public PlayerManager() {//NFL Player Manager Class has a constructor.
		createPlayers();
	}

	public static void createPlayers() {//NFL Player Manager Class has a createPlayers method that creates 10 players.
		NFLPlayer mcafee = new NFLPlayer("Pat McAfee", 30, 73, 233, 0, 1, 1, 0, 35, 0, 0, 0, 1, 118.8);
		NFLPlayer luck = new NFLPlayer("Andrew Luck", 27, 76, 240, 31, 545, 64, 2, 4240, 341, 6, 5, 346, 96.4);
		NFLPlayer cook = new NFLPlayer("Connor Cook", 24, 76, 217, 1, 21, 0, 0, 150, 0, 2, 1, 14, 83.4);
		NFLPlayer williams = new NFLPlayer("Jonathan Williams", 23, 72, 223, 0, 1, 27, 1, 0, 94, 2, 2, 0, 39.6);
		NFLPlayer landry = new NFLPlayer("Jarvis Landry", 24, 71, 206, 0, 1, 5, 0, 0, 17, 2, 2, 0, 39.6);
                NFLPlayer bell = new NFLPlayer("Le'Veon Bell", 25, 73, 225, 0, 1, 261, 7, 0, 1268, 4, 1, 0, 39.6);
                NFLPlayer mallett = new NFLPlayer("Ryan Mallett", 29, 78, 250, 0, 6, 5, 0, 26, -6, 0, 0, 3, 22.2);
		NFLPlayer whitehurst = new NFLPlayer("Charlie Whitehurst", 34, 77, 226, 1, 24, 2, 0, 182, 1, 0, 0, 14, 78.8);
		NFLPlayer savage = new NFLPlayer("Tom Savage", 27, 76, 230, 0, 73, 6, 0, 461, 12, 1, 1, 46, 80.9);
		NFLPlayer mccown = new NFLPlayer("Josh McCown", 38, 76, 218, 6, 165, 7, 0, 1100, 21, 7, 4, 90, 72.3);

		LIST_OF_PLAYERS.add(mcafee);
		LIST_OF_PLAYERS.add(luck);
		LIST_OF_PLAYERS.add(cook);
                LIST_OF_PLAYERS.add(williams);
		LIST_OF_PLAYERS.add(landry);
		LIST_OF_PLAYERS.add(bell);
		LIST_OF_PLAYERS.add(mallett);
		LIST_OF_PLAYERS.add(whitehurst);
		LIST_OF_PLAYERS.add(savage);
		LIST_OF_PLAYERS.add(mccown);
	}

    /**
     *
     * @return
     */
    @Override
	public String toString() {//NFL Player Manager Class has a toString method.
		String list = "";
		for (NFLPlayer n : LIST_OF_PLAYERS)
			list += (n.name + " " + LIST_OF_PLAYERS.indexOf(n) + "\n");
		return list;
	}

public static void main(String[] args) {
   // Testing the constructor
		PlayerManager test = new PlayerManager();

		// Testing toString
		System.out.println(test.toString());

		// Testing Getters
                //The driver method displays the 10 players on the console.
		System.out.println("\nMalletts's Stats:\nPassing TD%: " + PlayerManager.LIST_OF_PLAYERS.get(6).getPassingTouchDownPercent()
				+ "%\nPassing YDS AVG:" + PlayerManager.LIST_OF_PLAYERS.get(6).getPassingYardAverage() + "\nRushing YDS AVG: "
				+ PlayerManager.LIST_OF_PLAYERS.get(6).getRushingYardAverage() + "\nComp%: "
				+ PlayerManager.LIST_OF_PLAYERS.get(6).getCompletionPercent() + "%");
		
		// Testing Setters
		PlayerManager.LIST_OF_PLAYERS.get(6).setPassingAttempts(20);
		PlayerManager.LIST_OF_PLAYERS.get(6).setPassingTouchDowns(100);
		System.out.println("Setter Test: Malletts Passing TD% now equals " + PlayerManager.LIST_OF_PLAYERS.get(6).getPassingTouchDownPercent() + "%");
	}
} 